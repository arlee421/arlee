
const conveniencefoodList = document.querySelector("#convenience-list");
const form = document.querySelector("#add-list-form");
const login = document.querySelector("#form-container")

//uuid 취득 - 개인 확인 용 (삭제 / 음식 먹은거 확인용 버튼 )  랜덤 취득으로 계속 바뀌니까 개인 uuid 저장 토록 앱 처음 실행시 만들어놓자
function uuidv4() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

var setCookie = function(name, value, exp) {
  var date = new Date();
  date.setTime(date.getTime() + exp*24*60*60*1000);
  document.cookie = name + '=' + value + ';expires=' + date.toUTCString() + ';path=/';
  };
  
var getCookie = function(name) {
    var value = document.cookie.match('(^|;) ?' + name + '=([^;]*)(;|$)');
    return value? value[2] : null;
};
    
    
  
let uuid = getCookie("uuid");
console.log("savedUUID",uuid);

if(uuid==null){
  uuid=uuidv4();
  console.log("setUUID", uuid );

  setCookie("uuid", uuid, 1);
}


//초기정보 불러오기 

var date = document.getElementById('date');
var menu = document.getElementById('menu');

var availablePerson = document.getElementById('applyAvailable');
var availableTime= document.getElementById('applyTime');

var applyCheckPerson ; 
var listsize;
var dbstime;
var dbftime; 
var dbdate = new Date() ;
var listName; 


// Create a reference with an initial file path and name
var storage = firebase.storage();
var storageRef = storage.ref();

// Create a reference to the file we want to download
var menuImageRef = storageRef.child('CKBS_Rest/todaymenu.jpg');


/* 초기정보 불러오기 */
var dayInfoRef = inidb.collection("adminInfo");
dayInfoRef.doc("adminDayInfo").get().then(function(doc){

  if(doc.exists) {
  listName = doc.data().date;
 
  if(doc.data().date!="준비중"){
   dbdate = new Date(doc.data().date);
   date.textContent= dbdate.toISOString().substring(0,10);
  }
 
  menu.textContent ="오늘의 메뉴 : "+doc.data().menu;


    // Get the download URL
  menuImageRef.getDownloadURL().then(function(url) {
  if(listName=="준비중"){
    document.getElementById("img").src = "./images/unnamed.png";
  }else{
    document.getElementById("img").src = url;
  }
}).catch(function(error) {

 // A full list of error codes is available at
 // https://firebase.google.com/docs/storage/web/handle-errors
 switch (error.code) {
   case 'storage/object-not-found':
     // File doesn't exist
     console.log("찾을 수 없음");
     break;

   case 'storage/unauthorized':
     // User doesn't have permission to access the object
     console.log("권한 없음");
     break;

   case 'storage/canceled':
     // User canceled the upload
     break;

   case 'storage/unknown':
     // Unknown error occurred, inspect the server response
     break;
 }
});

  /*realTime Database */
  db.collection(listName)
  .orderBy("name")
  .onSnapshot(snapshot => {
    let changes = snapshot.docChanges();
    
    finishApply.textContent=snapshot.size + "명";
    applyCheckPerson= listsize-snapshot.size;
    availablePerson.textContent = applyCheckPerson + "명";

    changes.forEach(change => {
      console.log(change.doc.data());
      if (change.type == "added") {
    
        renderList(change.doc);
      
      } else if (change.type == "removed") {
        let li = conveniencefoodList.querySelector("[data-id=" + change.doc.id + "]");
        
        conveniencefoodList.removeChild(li);
      }
    });

  });

  }else {
    console.log("No such document!");
  }
}).catch(function(error) {
  console.log("Error getting document:", error);

});


var initialRef = db.collection("adminInfo");
initialRef.doc("adminSystem").get().then(function(doc) {
  if (doc.exists) {

      listsize= doc.data().available;
      dbstime= doc.data().stime;
      dbftime= doc.data().ftime;
      var date = new Date(Date.now());
      
      availableTime.textContent= dbstime+"~"+dbftime;

      dbstime = dbdate.toISOString().substring(0,11)+dbstime;
      dbftime = dbdate.toISOString().substring(0,11)+dbftime;

      dbstime=new Date(dbstime);
      dbftime=new Date(dbftime);
      
      console.log("dbstime" + dbstime);
      console.log("dbftime" + dbftime);
      console.log("date"+ date);
      console.log(dbstime<date);
      console.log(dbftime>date);

   } else {
      // doc.data() will be undefined in this case
     console.log("No such document!");
   }
 }).catch(function(error) {
   console.log("Error getting document:", error);

});

/*리스트 불러오기*/
function renderList(doc) {


   if(doc.data().uuid==uuid){
  let li = document.createElement("li");
  let division = document.createElement("span");
  let name = document.createElement("span");
  let button = document.createElement("button");

  li.setAttribute("data-id", doc.id);


  division.textContent = leadingSpaces(doc.data().division,10);
  
  name.textContent = doc.data().name;
  var status = doc.data().status;

  if (status==0&&Date.now()>dbstime&&Date.now()<dbftime){

     button.textContent = "취소";   // todo 시간 설정에 따라 삭제 & 확인 버튼으로 나눠서 운영 

  }else if(status==1){
    button.textContent = "수령 완료";
    button.style.backgroundColor="#999";
  }else{
    button.textContent = "수령 확인";
  }


  li.appendChild(division);
  li.appendChild(name); 
  li.appendChild(button);

  conveniencefoodList.appendChild(li);
   
  // deleting data    X 선택시 삭제 됨!!!!!    
  button.addEventListener("click", e => {
    e.stopPropagation();
    
    let id = e.target.parentElement.getAttribute("data-id");
    
    var docRef = db.collection(listName).doc(id);

    docRef.get().then(function(doc) {
        if (doc.exists) {

            console.log("Document data:", doc.data().status);

            if(doc.data().status==0&&Date.now()>dbstime&&Date.now()<dbftime){

                db.collection(listName)
                .doc(id)
                .delete();
                alert("신청을 취소 하였습니다.");
        
                
           }else if (doc.data().status==0) {
              alert("음식을 수령 하였습니다. ");
               button.textContent = "수령 완료";
               button.style.backgroundColor="#999";
               docRef.update({ status : 1});

           } else{
            alert("이미 수령 완료 하였습니다. ");
           }
      

        } else {
            // doc.data() will be undefined in this case
            console.log("No such document!");
        }
    }).catch(function(error) {
        console.log("Error getting document:", error);
    });
    // [END get_document]

  });
   }
}
 
// saving data   
form.addEventListener("submit", e => {
  e.preventDefault();

  var date = new Date( Date.now());

  if (date>dbstime&&date<dbftime&&applyCheckPerson>0&&listName!="준비중"){
    

      if(form.division.value!="담당부서"&&form.name.value!="") {
        db.collection(listName).add({
        division: form.division.value,
        name: form.name.value,
        uuid: uuid,
        status: 0   // 초기치
      });
      alert("신청이 완료 되었습니다." +date.toString());
    }else{
      alert("담당부서 혹은 이름을 입력해주세요 ");
    }
  }else if(applyCheckPerson>0){
  

    alert( date>dbstime);
    alert( dbftime>date); 
 

  }else{
    alert("신청 가능 인원을 초과 하였습니다.");
  }
  
  form.division.value = "";
  form.name.value = "";

});



function PopupDialog(setMsg) {
  var myDialog = document.createElement("dialog");
  document.body.appendChild(myDialog)
  var form = document.createElement("form");
  var title = document.createTextNode("간편식 알림");
  var text = document.createElement("p");
  var button = document.createElement("button");

  text.textContent=setMsg;
  button.textContent="확인";
  form.appendChild(title);
  form.appendChild(text);
  form.appendChild(button);
  myDialog.appendChild(form);
  myDialog.showModal();

  myDialog.addEventListener('close', function onClose() {
   
  });
}


function leadingSpaces(n, digits) {
	var space = '';
	n = n.toString();
  
	if (n.length < digits) {
	  for (var i = 0; i < digits - n.length; i++)
		space += "\u00A0 ";
	}
	return n +space;
  }

/*
function changeImage(imageID){

  switch (imageID){
    case "길거리토스트" :
        document.getElementById("img").src = "./images/toast.jpg";
        break;
    case "잉글리쉬머핀햄버거" :
      document.getElementById("img").src = "./images/english_muffin.jpg";
        break;
    case "핫도그샌드위치" :
      document.getElementById("img").src = "./images/hotdog.jpg";
        break;
    case "김밥" :
      document.getElementById("img").src = "./images/kimbab.jpg";
          break;
    case "샌드위치" :
      document.getElementById("img").src = "./images/sandwich.jpg";
        break;
    case "준비중" :    
      document.getElementById("img").src = "./images/unnamed.png";
       break;
    default :
      document.getElementById("img").src = "./images/unnamed.png";
      break;
  }


}  

*/
