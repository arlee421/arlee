const conveniencefoodList = document.querySelector("#convenience-list");
const form = document.querySelector("#add-list-form");


let dbPerson = document.getElementById('person');
let dbStartTime = document.getElementById('startT');
let dbFinishTime = document.getElementById('finishT');
let dbdate = document.getElementById('date');
let dbmenu = document.getElementById('menu');
let dbmenuImg= document.getElementById('img');
let loadingbut = document.getElementById('loading');
let deletebut = document.getElementById('delete');
let makebut = document.getElementById('make');
let updatebut = document.getElementById('update');
let exportbut = document.getElementById('export');


// Create a reference with an initial file path and name
var storage = firebase.storage();
var storageRef = storage.ref();

// Create a reference to the file we want to download
var menuImageRef = storageRef.child('CKBS_Rest/todaymenu.jpg');



/* 초기정보 불러오기 */
let dayInfoRef = db.collection("adminInfo");
dayInfoRef.doc("adminDayInfo").get().then(function(doc){

  dbdate.value= doc.data().date;
  dbmenu.value= doc.data().menu; 


  // Get the download URL
menuImageRef.getDownloadURL().then(function(url) {
  if(dbmenu.value=="준비중"){
    dbmenuImg.src= "./images/unnamed.png";
  }else{
  dbmenuImg.src = url;
  }
}).catch(function(error) {

 // A full list of error codes is available at
 // https://firebase.google.com/docs/storage/web/handle-errors
 switch (error.code) {
   case 'storage/object-not-found':
     // File doesn't exist
     console.log("찾을 수 없음");
     break;

   case 'storage/unauthorized':
     // User doesn't have permission to access the object
     console.log("권한 없음");
     break;

   case 'storage/canceled':
     // User canceled the upload
     break;

   case 'storage/unknown':
     // Unknown error occurred, inspect the server response
     break;
 }
});
  
  var countAngel = 0 ;

  let tr=document.createElement("tr"); 
  let total =document.createElement("td");
  let ckbs =document.createElement("td");
  let angel =document.createElement("td");

  tr.appendChild(total);
  tr.appendChild(ckbs);
  tr.appendChild(angel);
  
  tr.style.backgroundColor="yellow";
  conveniencefoodList.appendChild(tr);

  let li = document.createElement("tr"); 
  let division = document.createElement("td");
  let name = document.createElement("td");
  let statusInfo = document.createElement("td");

  division.textContent="담당";
  name.textContent="이름";
  statusInfo.textContent="상태";

  li.appendChild(division);
  li.appendChild(name); 
  li.appendChild(statusInfo);

  li.style.backgroundColor="#CCC";

  conveniencefoodList.appendChild(li);


  /*realTime Database */
  inidb.collection(doc.data().date)
  .orderBy("name")
  .onSnapshot(snapshot => {
	let changes = snapshot.docChanges();

  changes.forEach(change => {
    //   console.log(change.doc.data());
      if (change.type == "added") {
    
        renderList(change.doc);
        if(change.doc.data().division=="엔젤위드") {
          countAngel=countAngel+1; 
          console.log("DATA",countAngel)}
    
      
      } else if (change.type == "removed") {
        let li = conveniencefoodList.querySelector("[data-id=" + change.doc + "]");
        
        conveniencefoodList.remove;
        
      }
    });
    total.textContent="신청인원 : "+ snapshot.size + "명";
    ckbs.textContent="CKBS : " + (snapshot.size - countAngel)+"명"
    angel.textContent = "엔젤위드 : "+ countAngel +"명"; 
});

});




let initialRef = db.collection("adminInfo");
initialRef.doc("adminSystem").get().then(function(doc) {
  if (doc.exists) {

      doc.data().password;
	 
	  dbPerson.value= doc.data().available;
	  dbStartTime.value = doc.data().stime;
	  dbFinishTime.value= doc.data().ftime;

   } else {
      // doc.data() will be undefined in this case
     console.log("No such document!");
   }
 }).catch(function(error) {
   console.log("Error getting document:", error);

});

/*리스트 불러오기*/
function renderList(doc) {
  
	let li = document.createElement("tr"); 
	let division = document.createElement("td");
	let name = document.createElement("td");
  let statusInfo = document.createElement("td");

	li.setAttribute("data-id", doc.id);
      
	division.textContent= doc.data().division;
	name.textContent = doc.data().name;
	var status = doc.data().status;
  
	if (status==0){
		statusInfo.textContent = "신청완료";   
		statusInfo.style.color="blue";
	}else {
		statusInfo.textContent = "수령완료";
	}
  
	li.appendChild(division);
	li.appendChild(name); 
	li.appendChild(statusInfo);

	conveniencefoodList.appendChild(li);
  }

   /* 공백 넣기 */
  function leadingSpaces(n, digits) {
	var space = '';
	n = n.toString();
  
	if (n.length < digits) {
	  for (var i = 0; i < digits - n.length; i++)
		space += "\u00A0 ";
	}
	return n +space;
  }

  updatebut.addEventListener("click", e=> {
	e.preventDefault();

	if(dbPerson.value==""){
		alert("신청 가능 인원을 입력 하세요.")
	}else{

	db.collection("adminInfo").doc("adminSystem").update({
		available : dbPerson.value,
		stime : dbStartTime.value ,
		ftime : dbFinishTime.value
		});

		alert("갱신완료");
 	 }
	});

  deletebut.addEventListener("click", e=> {
		e.preventDefault();
		
	db.collection("adminInfo").doc("adminDayInfo").set({
		date : "준비중",
		menu : "준비중"
		});
		dbdate.value="";
    dbmenu.value="";
    
    while (conveniencefoodList.firstChild) {
      conveniencefoodList.removeChild(conveniencefoodList.firstChild)
    }

		alert("준비중 변경 완료");
  });

   makebut.addEventListener("click", e=> {
		e.preventDefault();

		if(dbmenu.value==""){
			alert("오늘의 메뉴를 입력해주세요")
		}else{

		db.collection("adminInfo").doc("adminDayInfo").set({
			date : dbdate.value,
			menu : dbmenu.value
    });
    
    alert("생성 완료");

    while (conveniencefoodList.firstChild) {
      conveniencefoodList.removeChild(conveniencefoodList.firstChild)
    }

  gettingData();
    
	}

	});
	
	exportbut.addEventListener("click", e=> {
		e.preventDefault();
			
		fnExcelReport("convenience-list","간편식"+dbdate.value);
	
		alert("Excel export완료");
		
	});
  
  function gettingData(){

    let tr=document.createElement("tr"); 
    let total =document.createElement("td");
    let ckbs =document.createElement("td");
    let angel =document.createElement("td");
    let countAngel =0;
    
    tr.appendChild(total);
    tr.appendChild(ckbs);
    tr.appendChild(angel);
    tr.style.backgroundColor="yellow";
    conveniencefoodList.appendChild(tr);
    
    
    let li = document.createElement("tr"); 
    let division = document.createElement("td");
    let name = document.createElement("td");
    let statusInfo = document.createElement("td");
    
    division.textContent="담당";
    name.textContent="이름";
    statusInfo.textContent="상태";
    
    li.appendChild(division);
    li.appendChild(name); 
    li.appendChild(statusInfo);
    
    li.style.backgroundColor="#CCC";
    conveniencefoodList.appendChild(li);
  
      db.collection(dbdate.value).orderBy("name").get().then(snapshot => {
  
        total.textContent="신청인원 : "+ snapshot.size + "명";
  
      
        snapshot.docs.forEach(doc => {
       
            renderList(doc);
            if(doc.data().division=="엔젤위드") {
              countAngel=countAngel+1; 
              console.log("DATA",countAngel)}
      
          });
  
          ckbs.textContent="CKBS : " + (snapshot.size - countAngel)+"명"
          angel.textContent = "엔젤위드 : "+ countAngel +"명"; 
      
          
      });
  }    


