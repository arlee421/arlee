const dietlist = document.querySelector("#diet-list");
const form = document.querySelector("#add-list-form");

let dbPerson = document.getElementById('person');
let dbStartTime = document.getElementById('startT');
let dbFinishTime = document.getElementById('finishT');
let dbsdate = document.getElementById('startdate');
let dbfdate = document.getElementById('finishdate');
let loadingbut = document.getElementById('loading');
let deletebut = document.getElementById('delete');
let makebut = document.getElementById('make');
let updatebut = document.getElementById('update');
let exportbut = document.getElementById('export');
var listName; 

/* 초기정보 불러오기 */
let dayInfoRef = db.collection("adminInfo");
dayInfoRef.doc("adminDietInfo").get().then(function(doc){

  dbsdate.value= doc.data().operatedSday;
  dbfdate.value= doc.data().operatedFday; 
  var countAngel = 0 ;

  let tr=document.createElement("tr"); 
  let total =document.createElement("td");
  let ckbs =document.createElement("td");
  let angel =document.createElement("td");

  listName = doc.data().operatedSday.substring(5)+"~"+doc.data().operatedFday.substring(5);
  tr.appendChild(total);
  tr.appendChild(ckbs);
  tr.appendChild(angel);
  
  tr.style.backgroundColor="yellow";
  dietlist.appendChild(tr);

  let li = document.createElement("tr"); 
  let division = document.createElement("td");
  let name = document.createElement("td");
  let statusInfo = document.createElement("td");

  division.textContent="담당";
  name.textContent="이름";
  statusInfo.textContent="상태";

  li.appendChild(division);
  li.appendChild(name); 
  li.appendChild(statusInfo);

  li.style.backgroundColor="#CCC";


  dietlist.appendChild(li);


  /*realTime Database */
  inidb.collection(listName)
  .orderBy("name")
  .onSnapshot(snapshot => {
	let changes = snapshot.docChanges();

  changes.forEach(change => {
   
      if (change.type == "added") {
    
        renderList(change.doc);
        if(change.doc.data().division=="엔젤위드") {
          countAngel=countAngel+1; 
          console.log("DATA",countAngel)}
    
      
      } else if (change.type == "removed") {
        let li = dietlist.querySelector("[data-id=" + change.doc + "]");
        
        dietlist.remove;
        
      }
    });
    total.textContent="신청인원 : "+ snapshot.size + "명";
    ckbs.textContent="CKBS : " + (snapshot.size - countAngel)+"명"
    angel.textContent = "엔젤위드 : "+ countAngel +"명"; 
});

});

let initialRef = db.collection("adminInfo");
initialRef.doc("adminDietInfo").get().then(function(doc) {
  if (doc.exists) {

      doc.data().password;
	 
	  dbPerson.value= doc.data().available;
	  dbStartTime.value = doc.data().stime;
	  dbFinishTime.value= doc.data().ftime;

   } else {
      // doc.data() will be undefined in this case
     console.log("No such document!");
   }
 }).catch(function(error) {
   console.log("Error getting document:", error);

});

/*리스트 불러오기*/
function renderList(doc) {
  
	let li = document.createElement("tr"); 
	let division = document.createElement("td");
	let name = document.createElement("td");
  let statusInfo = document.createElement("td");

	li.setAttribute("data-id", doc.id);
      
	division.textContent= doc.data().division;
	name.textContent = doc.data().name;
	var status = doc.data().status;
  
	if (status==0){
		statusInfo.textContent = "신청완료";  
		statusInfo.style.color="blue";
	}else {
		statusInfo.textContent = "수령완료";
	}
  
	li.appendChild(division);
	li.appendChild(name); 
	li.appendChild(statusInfo);

	dietlist.appendChild(li);
  }

   /* 공백 넣기 */
  function leadingSpaces(n, digits) {
	var space = '';
	n = n.toString();
  
	if (n.length < digits) {
	  for (var i = 0; i < digits - n.length; i++)
		space += "\u00A0 ";
	}
	return n +space;
  }

  updatebut.addEventListener("click", e=> {
	e.preventDefault();

	if(dbPerson.value==""){
		alert("신청 가능 인원을 입력 하세요.")
	}else{

	db.collection("adminInfo").doc("adminDietInfo").update({
		available : dbPerson.value,
		stime : dbStartTime.value ,
		ftime : dbFinishTime.value
		});

		alert("갱신완료");
 	 }
	});

  deletebut.addEventListener("click", e=> {
		e.preventDefault();
		
	db.collection("adminInfo").doc("adminDietInfo").update({
        operatedSday : "준비중",
        operatedFday :  "준비중"
		});
		dbsdate.value="";
        dbfdate.value="";
        
        while (dietlist.firstChild) {
            dietlist.removeChild(dietlist.firstChild)
        }
        
        alert("준비중 변경 완료");
  });

   makebut.addEventListener("click", e=> {
		e.preventDefault();

		if(dbsdate.value==""||dbfdate.value==""){
			alert("시작 기간 or 종료기간을 입력해 주세요")
		}else{

		db.collection("adminInfo").doc("adminDietInfo").update({
			operatedSday : dbsdate.value,
			operatedFday : dbfdate.value
    });
    
    alert("생성 완료");

    while (dietlist.firstChild) {
        dietlist.removeChild(dietlist.firstChild)
    }

  gettingData();
    
	}

	});
	
	exportbut.addEventListener("click", e=> {
		e.preventDefault();
			
      fnExcelReport("diet-list", "다이어트식"+listName);
        
    //     var confirm_test = confirm("export한 DB를 삭제 하시겠습니까? ");
 
    // if ( confirm_test == true ) {
    //     // 확인(예) 버튼 클릭 시 이벤트
    //     db.collection(listName)
    //     .get()
    //     .then(res => {
    //       res.forEach(element => {
    //     element.ref.delete();
    //    });
    //   });
    //   alert("DB를 삭제 하였습니다. ");
    //   while (dietlist.firstChild) {
    //     dietlist.removeChild(dietlist.firstChild)
    //    }
    // } else if ( confirm_test == false ) {
    //     // 취소(아니오) 버튼 클릭 시 이벤트
    //     alert("DB를 삭제를 취소 하였습니다. "); 
    // }
	});
  
  function gettingData(){

    let tr=document.createElement("tr"); 
    let total =document.createElement("td");
    let ckbs =document.createElement("td");
    let angel =document.createElement("td");
    let countAngel =0;
    
    tr.appendChild(total);
    tr.appendChild(ckbs);
    tr.appendChild(angel);
    tr.style.backgroundColor="yellow";
    dietlist.appendChild(tr);
    
    
    let li = document.createElement("tr"); 
    let division = document.createElement("td");
    let name = document.createElement("td");
    let statusInfo = document.createElement("td");
    
    division.textContent="담당";
    name.textContent="이름";
    statusInfo.textContent="상태";
    
    li.appendChild(division);
    li.appendChild(name); 
    li.appendChild(statusInfo);
    
    li.style.backgroundColor="#CCC";
    dietlist.appendChild(li);
  
      db.collection(dbdate.value).orderBy("name").get().then(snapshot => {
  
        total.textContent="신청인원 : "+ snapshot.size + "명";
  
      
        snapshot.docs.forEach(doc => {
       
            renderList(doc);
            if(doc.data().division=="엔젤위드") {
              countAngel=countAngel+1; 
              console.log("DATA",countAngel)}
      
          });
  
          ckbs.textContent="CKBS : " + (snapshot.size - countAngel)+"명"
          angel.textContent = "엔젤위드 : "+ countAngel +"명"; 
      
          
      });
  }    

