const oldList = document.querySelector("#old-list");

let dbdate = document.getElementById('date');
let deletebut = document.getElementById('delete');
let loadingbut = document.getElementById('loading');
let exportbut = document.getElementById('export');




/*리스트 불러오기*/
function renderList(doc) {

	let li = document.createElement("tr"); 
	let division = document.createElement("td");
	let name = document.createElement("td");
	let statusInfo = document.createElement("td");
	
	li.setAttribute("data-id", doc.id);
  
	division.textContent= doc.data().division;
	name.textContent = doc.data().name;
	var status = doc.data().status;
  
	if (status==0){
    statusInfo.textContent = "수령 전";   
    statusInfo.style.color="blue"; 
	}else{
		statusInfo.textContent = "수령 완료"
	
	}
  
	li.appendChild(division);
	li.appendChild(name); 
	li.appendChild(statusInfo);

	oldList.appendChild(li);
  }

 /* 공백 넣기 */
function leadingSpaces(n, digits) {
    var space = '';
    n = n.toString();
      
    if (n.length < digits) {
        for (var i = 0; i < digits - n.length; i++)
            space += "\u00A0 ";
    }
    return n +space;
}


deletebut.addEventListener("click", e=> {
    e.preventDefault();
    
    /*쿼리 삭제 */
	db.collection(dbdate.value)
  	.get()
 	 .then(res => {
   	 res.forEach(element => {
	  element.ref.delete();
	});
  });

     dbdate.value="";
   
     while (oldList.firstChild) {
        oldList.removeChild(oldList.firstChild)
      }

      alert("삭제완료");
   
});

loadingbut.addEventListener("click", e=> {
    e.preventDefault();
    while (oldList.firstChild) {
        oldList.removeChild(oldList.firstChild)
      }

    gettingData();
  
    alert("로딩완료");
});

exportbut.addEventListener("click", e=> {
  e.preventDefault();
  
  fnExcelReport("old-list", "간편식"+dbdate.value);

  alert("Excel export완료");

});


/* 신청한 리스트 불러오기 */
function gettingData(){
  var countAngel = 0 ;
  let tr=document.createElement("tr"); 
  let total =document.createElement("td");
  let ckbs =document.createElement("td");
  let angel =document.createElement("td");
  
  tr.appendChild(total);
  tr.appendChild(ckbs);
  tr.appendChild(angel);
  tr.style.backgroundColor="yellow";
  oldList.appendChild(tr);
  
  
  let li = document.createElement("tr"); 
  let division = document.createElement("td");
  let name = document.createElement("td");
  let statusInfo = document.createElement("td");
  
  division.textContent="담당";
  name.textContent="이름";
  statusInfo.textContent="상태";
  
  li.appendChild(division);
  li.appendChild(name); 
  li.appendChild(statusInfo);
  
  li.style.backgroundColor="#CCC";
  oldList.appendChild(li);

    db.collection(dbdate.value).orderBy("name").get().then(snapshot => {

      total.textContent="신청인원 : "+ snapshot.size + "명";

    
      snapshot.docs.forEach(doc => {
     
          renderList(doc);
          if(doc.data().division=="엔젤위드") {
            countAngel=countAngel+1; 
            console.log("DATA",countAngel)}
    
        });

        ckbs.textContent="CKBS : " + (snapshot.size - countAngel)+"명"
        angel.textContent = "엔젤위드 : "+ countAngel +"명"; 
    
        
    });
}    

db.collection(dbdate.value)
.orderBy("name")
.onSnapshot(snapshot => {
  let changes = snapshot.docChanges();
  console.log("realTime 실행됨");
  changes.forEach(change => {
  //   console.log(change.doc.data());
    if (change.type == "added") {
  
      renderList(change.doc);
    
    } else if (change.type == "removed") {
      let li = oldList.querySelector("[data-id=" + change.doc + "]");
      
      oldList.removeChild(li);
      
    }
  });
});

