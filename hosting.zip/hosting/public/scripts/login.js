let adminpassword = document.getElementById('adminPW');
let loginbut = document.getElementById('login');
let closebut = document.getElementById('close');

var index = getParameter("index");
console.log("index",index);

loginbut.addEventListener("click", e=> {
	e.preventDefault();
	
	db.collection("adminInfo").doc("adminSystem").get().then(function(doc){
	
		if(doc.data().password==adminpassword.value) {
			

			if(index=="456"){
			location.replace("admin.html")
	    	}else{
				location.replace("dietAdmin.html")	
			}

		}else{
			alert("비밀번호를 확인해주세요");
			adminpassword.value="";
		}
	});	
});

closebut.addEventListener("click", e=> {
	e.preventDefault();

	if(index=="456"){
		location.replace("admin.html")
		}else{
			location.replace("dietAdmin.html")	
		}
	
});

function getParameter(name) {
    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
    var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
        results = regex.exec(location.search);
    return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
}

